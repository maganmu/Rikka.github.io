respectMattt
============

respectMattt is theme for Octopress.

## Install

	$ cd octopress
	$ git clone git://github.com/midnightSuyama/respectMattt.git .themes/respectMattt
	$ rake install['respectMattt']
	$ rake generate

If zsh, please use `rake install\['respectMattt'\]`.

## Configuration

### Theme

Change category name in `.themes/respectMattt/source/_includes/post/theme.html`.

## Acknowledgements

respectMattt was inspired by the mattt.

* [Bootstrap](http://getbootstrap.com)
* [Font Awesome](http://fortawesome.github.io/Font-Awesome/)
* [jQuery](http://jquery.com)
* [Isotope](http://isotope.metafizzy.co)
* [Lettering.js](http://letteringjs.com)
* [Subtle Patterns](http://subtlepatterns.com)
* [mini Social Icons](http://wolfrosch.com)
